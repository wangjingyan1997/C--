#include <stdio.h>
int main()
{
	printf("\"How many student here?\"");
	printf("\n");
	printf("\"500\"");
	return 0;
} 
