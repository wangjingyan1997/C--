#include <stdio.h> 
#define PI 3.1415926 
int main()  
{ 
    float r,s;  
    printf("������Բ�뾶��");  
    scanf("%f",&r);   
    s = PI * r * r;
	printf("%.7f %f\n",PI,r);
    printf("%4.2f\n",s);    
    return 0;  
} 
